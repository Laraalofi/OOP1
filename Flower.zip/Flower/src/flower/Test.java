package flower;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Test {

    public static void main(String[] args) throws FileNotFoundException {

        // Create a object for Customer class
        Customer customer = new Customer();
        // Create a object for Flower class
        Flower flower = new Flower();
        // Create a object for Receipt class
        Receipt receipt = new Receipt();
        // Each object from Receipt class saved in list
        ArrayList<Receipt> list = new ArrayList<>();

        System.out.println(ConsoleColors.PURPLE_BOLD + "\t\t\t∘◦❀ Rose Shop ❀◦∘");

        int choice = 0;
        int count = 0;
        do {
            // Call show method to print options and saved in choice 
            choice = show();

            switch (choice) {
                case 1:
                    // Call addCustomer method from Test class and return it to Customer class by object
                    customer = addCustomer();
                    // Call menu methods from Test class and return it to Flower class by object
                    flower = menu();
                    // Create a object and Add to Receipt array list
                    list.add(new Receipt(customer, flower));
                    // Call metods to write to file 
                    list.get(count).writeToFile();
                    count++;
                    break;
                case 2:
                    showReceipt();
                    break;
                case 3:
                    receipt.deleteReceipt();
                    break;
                case 4:
                    //  To Exit from the program
                    System.out.println("\t\t\tSystem end ☺☺☺ ");
                    break;
                default:
                    //  Input validaiton
                    System.out.println("\t\t\tPlease, Choose another");
            }
        } while (choice != 4);
    }

//  ----------------------------------------------------------------------------------------------------------------
//  Print main options 
    public static int show() {

        Scanner in = new Scanner(System.in);
        System.out.println("\n\t\t❀✿❀✿❀✿❀✿❀✿❀✿❀✿❀✿❀✿❀✿❀✿❀✿");
        System.out.println("\t\t\t 1: Add Operation\t");
        System.out.println("\t\t\t 2: Show Receipt\t\t");
        System.out.println("\t\t\t 3: Delete Operation\t");
        System.out.println("\t\t\t 4: Exit\t\t\t");
        System.out.println("\t\t❀✿❀✿❀✿❀✿❀✿❀✿❀✿❀✿❀✿❀✿❀✿❀✿\n");
        int ch = in.nextInt();
        return ch;
    }
    
//  ----------------------------------------------------------------------------------------------------------------
    /**
     * This method to enter customer details and return them as an object of
     * Customer class
     *
     * @return
     */
    public static Customer addCustomer() {
        Scanner in = new Scanner(System.in);

        System.out.print("\t\t\tName Of The Sender: ");
        String name = in.nextLine();

        System.out.print("\t\t\tName Of The Person: ");
        String person = in.nextLine();

        int num;
        do {
            System.out.print("\t\t\tNumber For Communication✆: ");
            num = in.nextInt();
            //  Input validaiton for number 
            if (num >= 0) {
                break;
            } else {
                System.out.println("\t\t\tPlease, Choose a positive number: ");
            }
        } while (true);

        // Create new object from Customer class to send name, name of person and number to Customer class
        Customer ob = new Customer(name, person, num);
        return ob;
    }
    
//  ----------------------------------------------------------------------------------------------------------------
//  This method enables you to display the list of available flowers and
//  their details and return them as an object of Flower class
    public static Flower menu() {
        Scanner in = new Scanner(System.in);
        int num;
        int price = 0;
        do {
            System.out.println("\t\t\tNumber of Flowers❀: \n"
                    + "\t\t\t10 , 20 , 30 , 40 ");
            num = in.nextInt();
            if (num == 10) {
                price = 55;
                break;
            } else if (num == 20) {
                price = 110;
                break;
            } else if (num == 30) {
                price = 180;
                break;
            } else if (num == 40) {
                price = 220;
                break;
            } else {
                //  Input validaiton
                System.out.println("\t\t\tPlease, Choose another:");
            }
        } while (true);

        int num1 = 0;
        String Color = "";
        do {
            System.out.println("\t\t\tColors \n" + "\t\t\t1: Red ,2: Yellow ,3: Purple ");
            num1 = in.nextInt();
            if (num1 == 1) {
                Color = "Red";
                break;
            } else if (num1 == 2) {
                Color = "Yellow";
                break;
            } else if (num1 == 3) {
                Color = "Purple";
                break;
            } else {
                //  Input validaiton
                System.out.println("\t\t\tPlease, Choose another:");
            }
        } while (true);
        // Print the total price with %15 VAT of the flowers chosen by the user
        System.out.println("\t\t\tTotal Price = " + ((price * 0.15) + price) + " SAR");
        // Create new object to send number, color and price to Flower class
        Flower ob = new Flower(num, Color, price);
        return ob;
    }
    
//  ----------------------------------------------------------------------------------------------------------------
    /**
     * It asks to enter the name and then search for the appropriate invoice and
     * print it
     *
     * @throws FileNotFoundException
     */
    public static void showReceipt() throws FileNotFoundException {
        Scanner in = new Scanner(System.in);
        System.out.print("\t\t\tPlease, Enter The Sender's Name: ");
        String name = in.nextLine();
        // Create object for file
        File file = new File(name + ".txt");
        if (file.exists()) {
            Scanner scanner = new Scanner(file);
            while (scanner.hasNext()) {
                // if find it, print all the details
                System.out.println(scanner.nextLine());
            }
            scanner.close();
        } else {
            // not find it 
            System.out.println("\t\t\tReceipt not found ☒☒☒");
        }
    }
    
//  ----------------------------------------------------------------------------------------------------------------
//  Color methods
    public class ConsoleColors {
        public static final String PURPLE_BOLD = "\033[1;35m"; // PURPLE
    }
}
