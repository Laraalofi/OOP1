package flower;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Receipt {

//  Two object of the Customer and Flower class 
    private Customer customer;
    private Flower flower;

//  no-arg constructor
    public Receipt() {
        // we wrote our own constructor for the Customer class
        Customer customer = new Customer();
        // we wrote our own constructor for the Flower class
        Flower flower = new Flower();
    }

    /**
     * Receipt constructor the customer and flower objects
     *
     * @param customer object of the Customer class
     * @param flower object of the Flower class
     */
    public Receipt(Customer customer, Flower flower) {
        this.customer = customer;
        this.flower = flower;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public void setFlower(Flower flower) {
        this.flower = flower;
    }

    public Flower getFlower() {
        return flower;
    }
    
//  ----------------------------------------------------------------------------------------------------------------
//  Method to write the details for any file with the same name as the customer
    public void writeToFile() throws FileNotFoundException {
        PrintWriter writer = new PrintWriter(customer.getNameOfTheSender() + ".txt");
        // call toString from Receipt class
        writer.println(toString());
        writer.close();
    }
    
//  ----------------------------------------------------------------------------------------------------------------
//  Method to Find the receipt then delete it
    public static void deleteReceipt() {
        Scanner in = new Scanner(System.in);
        System.out.print("\t\t\tPlease, Enter The Sender's Name: ");
        String name = in.nextLine();
        File file = new File(name + ".txt");
        if (file.delete()) {
            System.out.println("\t\t\tReceipt deleted successfully ✔✔✔");
        } else {
            System.out.println("\t\t\tFailed to delete the file ☒☒☒");
        }
    }
    
//  OutputRoseShopProject----------------------------------------------------------------------------------------------------------------
//  Returns ALL information when called 
    @Override
    public String toString() {
        return "\n\n\n\t\t❀✿❀✿❀✿❀✿❀✿❀✿❀✿❀✿❀✿❀✿❀✿❀✿\n"
                + "\t\t\t Receipt info\n\n"
                //  call toString from Customer class to print all info there
                + customer.toString()
                //  call toString from Flower class to print all info there
                + flower.toString()
                + "\t\t❀✿❀✿❀✿❀✿❀✿❀✿❀✿❀✿❀✿❀✿❀✿❀✿\n\n\n\n";
    }
}
