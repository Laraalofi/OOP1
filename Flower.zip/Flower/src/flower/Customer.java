package flower;

public class Customer {
//  Fields 
    private String NameOfTheSender;
    private String NameOfThePerson;
    private int NumberForCommunication;

//  no-arg constructor
    public Customer() {
        NameOfTheSender = null;
        NameOfThePerson = null;
        NumberForCommunication = 0;
    }

    /**
     * Constructor
     *
     * @param nameOfTheSender
     * @param nameOfThePerson
     * @param numberForCommunication
     */
    public Customer(String nameOfTheSender, String nameOfThePerson, int numberForCommunication) {
        NameOfTheSender = nameOfTheSender;
        NameOfThePerson = nameOfThePerson;
        NumberForCommunication = numberForCommunication;
    }

    public String getNameOfTheSender() {
        return NameOfTheSender;
    }

    public void setNameOfTheSender(String nameOfTheSender) {
        NameOfTheSender = nameOfTheSender;
    }

    public String getNameOfThePerson() {
        return NameOfThePerson;
    }

    public void setNameOfThePerson(String nameOfThePerson) {
        NameOfThePerson = nameOfThePerson;
    }

    public int getNumberForCommunication() {
        return NumberForCommunication;
    }

    public void setNumberForCommunication(int numberForCommunication) {
        NumberForCommunication = numberForCommunication;
    }
    
//  ---------------------------------------------------------------------------------------------------------------- 
//  Returns ALL information when called  
    @Override
    public String toString() {
        return "\t┍**************************************************┑\n"
                + "\t\t\t Customer info\n\n"
                + "\t\t      Name Of The Sender: " + NameOfTheSender + "\n"
                + "\t\t      Name Of The Person: " + NameOfThePerson + "\n"
                + "\t\t      Number For Communication: 0" + NumberForCommunication + "✆\n"
                + "\t┖**************************************************┙\n";
    }
}
