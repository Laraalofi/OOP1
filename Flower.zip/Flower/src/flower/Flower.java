package flower;

public class Flower {

//  Fields
    private int NumberFlower;
    private String Color;
    private int price;
    

//  no-arg constructor
    public Flower() {
        NumberFlower = 0;
        Color = null;
        price = 0;
    }

    /**
     * Flower constructor
     *
     * @param numberFlower
     * @param color
     * @param price
     */
    public Flower(int numberFlower, String color, int price) {
        NumberFlower = numberFlower;
        Color = color;
        this.price = price;
    }

    public int getNumberFlower() {
        return NumberFlower;
    }

    public void setNumberFlower(int numberFlower) {
        NumberFlower = numberFlower;
    }

    public String getColor() {
        return Color;
    }

    public void setColor(String color) {
        Color = color;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
    
//  ----------------------------------------------------------------------------------------------------------------
//  Returns ALL information when called 
    @Override
    public String toString() {
        return "\t┍**************************************************┑\n"
                + "\t\t\t Flower info\n\n"
                + "\t\t      Number of Flowers: " + NumberFlower + "❀ \n"
                + "\t\t      Color: " + Color + "\n"
                + "\t\t      VAT %15 = " + price * 0.15 + " SAR\n"
                + "\t\t      Price = " + price + " SAR\n"
                + "\t\t      Total Price = " + ((price * 0.15) + price) + " SAR\n" // VAT Calculation 
                + "\t┖**************************************************┙\n";
    }
}
